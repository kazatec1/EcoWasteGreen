// Middleware para EcoWaste Green V6.0 Ultimate
// Roteamento, segurança e personalização na edge

import { NextResponse } from 'next/server'

export function middleware(request) {
  const { pathname, searchParams } = request.nextUrl
  const response = NextResponse.next()

  // Headers de segurança
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-XSS-Protection', '1; mode=block')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')

  // Detectar país e idioma
  const country = request.headers.get('cf-ipcountry') || 'US'
  const acceptLanguage = request.headers.get('accept-language') || 'en'
  
  // Mapear países para idiomas
  const countryLanguageMap = {
    'BR': 'pt',
    'US': 'en',
    'GB': 'en',
    'ES': 'es',
    'MX': 'es',
    'FR': 'fr',
    'DE': 'de',
    'IT': 'it',
    'JP': 'ja',
    'CN': 'zh',
    'KR': 'ko',
    'RU': 'ru',
    'IN': 'hi',
    'SA': 'ar'
  }

  const detectedLanguage = countryLanguageMap[country] || 'en'
  
  // Adicionar headers de localização
  response.headers.set('X-User-Country', country)
  response.headers.set('X-User-Language', detectedLanguage)

  // Rate limiting simples baseado em IP
  const ip = request.headers.get('x-forwarded-for') || 
             request.headers.get('x-real-ip') || 
             'unknown'
  
  // Em produção, implementaria rate limiting real com KV store
  response.headers.set('X-RateLimit-Limit', '1000')
  response.headers.set('X-RateLimit-Remaining', '999')

  // Roteamento personalizado
  if (pathname.startsWith('/api/')) {
    // Adicionar headers CORS para APIs
    response.headers.set('Access-Control-Allow-Origin', '*')
    response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
    response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With')
    
    // Log de API calls (em produção, enviaria para analytics)
    console.log(`API Call: ${request.method} ${pathname} from ${country} (${ip})`)
  }

  // Redirecionamento baseado em localização para páginas específicas
  if (pathname === '/') {
    // Adicionar parâmetros de localização
    const url = request.nextUrl.clone()
    url.searchParams.set('country', country)
    url.searchParams.set('lang', detectedLanguage)
    
    // Não redirecionar, apenas adicionar headers
    response.headers.set('X-Localization-Applied', 'true')
  }

  // Feature flags baseados em país/região
  const featureFlags = {
    'BR': ['marketplace', 'pix-payment', 'carbon-credits'],
    'US': ['marketplace', 'stripe-payment', 'carbon-credits'],
    'EU': ['marketplace', 'sepa-payment', 'gdpr-compliance'],
    'default': ['marketplace', 'basic-payment']
  }

  const userFeatures = featureFlags[country] || 
                      featureFlags['EU'].includes(country) ? featureFlags['EU'] : 
                      featureFlags['default']

  response.headers.set('X-Feature-Flags', JSON.stringify(userFeatures))

  // A/B Testing simples
  const abTestVariant = Math.random() > 0.5 ? 'A' : 'B'
  response.headers.set('X-AB-Test-Variant', abTestVariant)

  // Personalização de conteúdo baseada em horário local
  const userTimezone = request.headers.get('cf-timezone') || 'UTC'
  const currentHour = new Date().getUTCHours()
  
  let timeBasedMessage = 'Bem-vindo ao EcoWaste Green!'
  if (currentHour >= 6 && currentHour < 12) {
    timeBasedMessage = 'Bom dia! Pronto para reciclar hoje?'
  } else if (currentHour >= 12 && currentHour < 18) {
    timeBasedMessage = 'Boa tarde! Continue sua jornada sustentável!'
  } else if (currentHour >= 18 && currentHour < 22) {
    timeBasedMessage = 'Boa noite! Veja seu progresso de hoje!'
  } else {
    timeBasedMessage = 'Boa madrugada! Descanse bem, eco-guerreiro!'
  }

  response.headers.set('X-Time-Message', encodeURIComponent(timeBasedMessage))

  // Detecção de dispositivo
  const userAgent = request.headers.get('user-agent') || ''
  const isMobile = /Mobile|Android|iPhone|iPad/.test(userAgent)
  const isTablet = /iPad|Android(?!.*Mobile)/.test(userAgent)
  const isBot = /bot|crawler|spider/i.test(userAgent)

  response.headers.set('X-Device-Type', isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop')
  response.headers.set('X-Is-Bot', isBot.toString())

  // Configurações de cache baseadas no tipo de conteúdo
  if (pathname.startsWith('/api/edge/')) {
    // Cache curto para edge functions
    response.headers.set('Cache-Control', 'public, max-age=60, s-maxage=300')
  } else if (pathname.startsWith('/api/')) {
    // Sem cache para APIs dinâmicas
    response.headers.set('Cache-Control', 'no-cache, no-store, must-revalidate')
  } else if (pathname.includes('.')) {
    // Cache longo para assets estáticos
    response.headers.set('Cache-Control', 'public, max-age=31536000, immutable')
  }

  // Logging para analytics (em produção, enviaria para serviço de analytics)
  const logData = {
    timestamp: new Date().toISOString(),
    path: pathname,
    country,
    language: detectedLanguage,
    device: isMobile ? 'mobile' : isTablet ? 'tablet' : 'desktop',
    userAgent: userAgent.substring(0, 100),
    ip: ip.substring(0, 10) + '***', // Mascarar IP para privacidade
    abVariant: abTestVariant
  }

  console.log('Middleware Log:', JSON.stringify(logData))

  return response
}

// Configurar quais rotas o middleware deve processar
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!_next/static|_next/image|favicon.ico).*)',
  ],
}

