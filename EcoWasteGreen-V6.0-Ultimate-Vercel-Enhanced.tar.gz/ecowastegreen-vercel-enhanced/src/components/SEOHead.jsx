import React from 'react'
import Head from 'next/head'
import { generateMetaTags, generateStructuredData, seoConfig } from '../utils/seo'

const SEOHead = ({
  title,
  description,
  image,
  url,
  type = 'website',
  article = null,
  noindex = false,
  canonical = null,
  structuredData = null,
  additionalMeta = {}
}) => {
  const metaTags = generateMetaTags({
    title,
    description,
    image,
    url,
    type,
    article,
    noindex,
    canonical
  })

  // Gerar dados estruturados padrão
  const defaultStructuredData = [
    generateStructuredData('WebSite'),
    generateStructuredData('Organization'),
    generateStructuredData('WebApplication')
  ]

  const allStructuredData = structuredData 
    ? [...defaultStructuredData, ...structuredData]
    : defaultStructuredData

  return (
    <Head>
      {/* Meta tags básicas */}
      <title>{metaTags.title}</title>
      <meta name="description" content={metaTags.description} />
      <meta name="viewport" content={metaTags.viewport} />
      <meta name="robots" content={metaTags.robots} />
      
      {/* Canonical URL */}
      <link rel="canonical" href={metaTags.canonical} />
      
      {/* Open Graph */}
      <meta property="og:title" content={metaTags['og:title']} />
      <meta property="og:description" content={metaTags['og:description']} />
      <meta property="og:image" content={metaTags['og:image']} />
      <meta property="og:url" content={metaTags['og:url']} />
      <meta property="og:type" content={metaTags['og:type']} />
      <meta property="og:site_name" content={metaTags['og:site_name']} />
      <meta property="og:locale" content={metaTags['og:locale']} />
      
      {/* Twitter */}
      <meta name="twitter:card" content={metaTags['twitter:card']} />
      <meta name="twitter:site" content={metaTags['twitter:site']} />
      <meta name="twitter:creator" content={metaTags['twitter:creator']} />
      <meta name="twitter:title" content={metaTags['twitter:title']} />
      <meta name="twitter:description" content={metaTags['twitter:description']} />
      <meta name="twitter:image" content={metaTags['twitter:image']} />
      
      {/* Idioma */}
      <meta name="language" content={metaTags.language} />
      <meta httpEquiv="content-language" content={metaTags['content-language']} />
      
      {/* Tema e cores */}
      <meta name="theme-color" content={metaTags['theme-color']} />
      <meta name="msapplication-TileColor" content={metaTags['msapplication-TileColor']} />
      
      {/* Apple */}
      <meta name="apple-mobile-web-app-capable" content={metaTags['apple-mobile-web-app-capable']} />
      <meta name="apple-mobile-web-app-status-bar-style" content={metaTags['apple-mobile-web-app-status-bar-style']} />
      <meta name="apple-mobile-web-app-title" content={metaTags['apple-mobile-web-app-title']} />
      
      {/* Manifest */}
      <link rel="manifest" href={metaTags.manifest} />
      
      {/* Favicons */}
      <link rel="icon" type="image/x-icon" href="/favicon.ico" />
      <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png" />
      <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png" />
      <link rel="icon" type="image/png" sizes="192x192" href="/icons/android-chrome-192x192.png" />
      <link rel="icon" type="image/png" sizes="512x512" href="/icons/android-chrome-512x512.png" />
      
      {/* DNS Prefetch e Preconnect */}
      <link rel="dns-prefetch" href="//fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      
      {/* Preload de recursos críticos */}
      <link 
        rel="preload" 
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" 
        as="style" 
      />
      <link 
        rel="preload" 
        href="/images/hero-bg.webp" 
        as="image" 
        type="image/webp" 
      />
      
      {/* Fontes */}
      <link 
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" 
        rel="stylesheet" 
      />
      
      {/* Meta tags adicionais */}
      {Object.entries(additionalMeta).map(([key, value]) => (
        <meta key={key} name={key} content={value} />
      ))}
      
      {/* Tags específicas para artigos */}
      {type === 'article' && article && (
        <>
          <meta property="og:article:author" content={article.author || 'EcoWaste Green Team'} />
          <meta property="og:article:published_time" content={article.publishedTime} />
          <meta property="og:article:modified_time" content={article.modifiedTime} />
          <meta property="og:article:section" content={article.section || 'Sustentabilidade'} />
          <meta property="og:article:tag" content={article.tags?.join(', ') || 'reciclagem, sustentabilidade'} />
        </>
      )}
      
      {/* Dados estruturados */}
      {allStructuredData.map((data, index) => (
        <script
          key={`structured-data-${index}`}
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(data)
          }}
        />
      ))}
      
      {/* CSS crítico inline */}
      <style jsx>{`
        /* Critical CSS para Above-the-fold */
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          margin: 0;
          padding: 0;
          background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
        }
        
        .hero-section {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #22c55e, #3b82f6);
        }
        
        .loading-spinner {
          width: 40px;
          height: 40px;
          border: 4px solid #f3f3f3;
          border-top: 4px solid #22c55e;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        
        /* Otimizações de performance */
        * {
          box-sizing: border-box;
        }
        
        img {
          max-width: 100%;
          height: auto;
        }
        
        /* Prevenção de layout shift */
        .image-container {
          position: relative;
          overflow: hidden;
        }
        
        .image-container::before {
          content: '';
          display: block;
          padding-bottom: 56.25%; /* 16:9 aspect ratio */
        }
        
        .image-container img {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
      `}</style>
      
      {/* Analytics e Speed Insights */}
      {process.env.NODE_ENV === 'production' && (
        <>
          {/* Vercel Analytics */}
          <script
            dangerouslySetInnerHTML={{
              __html: `
                window.va = window.va || function () { (window.vaq = window.vaq || []).push(arguments); };
              `
            }}
          />
          
          {/* Vercel Speed Insights */}
          <script
            dangerouslySetInnerHTML={{
              __html: `
                window.si = window.si || function () { (window.siq = window.siq || []).push(arguments); };
              `
            }}
          />
          
          {/* Google Analytics (se configurado) */}
          {process.env.NEXT_PUBLIC_GA_ID && (
            <>
              <script
                async
                src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GA_ID}`}
              />
              <script
                dangerouslySetInnerHTML={{
                  __html: `
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);}
                    gtag('js', new Date());
                    gtag('config', '${process.env.NEXT_PUBLIC_GA_ID}', {
                      page_title: '${metaTags.title}',
                      page_location: '${metaTags.canonical}',
                    });
                  `
                }}
              />
            </>
          )}
        </>
      )}
      
      {/* Service Worker para PWA */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js')
                  .then(function(registration) {
                    console.log('SW registered: ', registration);
                  })
                  .catch(function(registrationError) {
                    console.log('SW registration failed: ', registrationError);
                  });
              });
            }
          `
        }}
      />
    </Head>
  )
}

export default SEOHead

