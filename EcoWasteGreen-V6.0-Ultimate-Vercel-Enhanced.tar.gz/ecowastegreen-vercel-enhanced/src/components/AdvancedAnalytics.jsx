import React, { useState, useEffect } from 'react'
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { TrendingUp, Users, Activity, Globe, Smartphone, Monitor, Tablet, Eye, Clock, Target } from 'lucide-react'

const AdvancedAnalytics = () => {
  const [analyticsData, setAnalyticsData] = useState(null)
  const [userActivity, setUserActivity] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedMetric, setSelectedMetric] = useState('overview')

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        // Buscar dados de analytics da Edge Function
        const [statsResponse, activityResponse] = await Promise.all([
          fetch('/api/edge/analytics?action=stats'),
          fetch('/api/edge/analytics?action=user-activity')
        ])

        const stats = await statsResponse.json()
        const activity = await activityResponse.json()

        setAnalyticsData(stats.data)
        setUserActivity(activity.data)
      } catch (error) {
        console.error('Erro ao carregar analytics:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnalytics()
    
    // Atualizar dados a cada 30 segundos
    const interval = setInterval(fetchAnalytics, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  const deviceData = [
    { name: 'Mobile', value: analyticsData?.deviceBreakdown?.mobile || 0, color: '#3B82F6' },
    { name: 'Desktop', value: analyticsData?.deviceBreakdown?.desktop || 0, color: '#10B981' },
    { name: 'Tablet', value: analyticsData?.deviceBreakdown?.tablet || 0, color: '#F59E0B' }
  ]

  const countryData = analyticsData?.topCountries || []

  const MetricCard = ({ title, value, icon: Icon, trend, color = "blue" }) => (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg bg-${color}-100`}>
          <Icon className={`w-6 h-6 text-${color}-600`} />
        </div>
        {trend && (
          <div className={`flex items-center text-sm ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
            <TrendingUp className="w-4 h-4 mr-1" />
            {trend > 0 ? '+' : ''}{trend}%
          </div>
        )}
      </div>
      <h3 className="text-gray-600 text-sm font-medium">{title}</h3>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Analytics Avançado - EcoWaste Green
          </h1>
          <p className="text-gray-600">
            Monitoramento em tempo real com Vercel Edge Functions
          </p>
        </div>

        {/* Métricas Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Usuários Totais"
            value={analyticsData?.totalUsers?.toLocaleString() || '0'}
            icon={Users}
            trend={12.5}
            color="blue"
          />
          <MetricCard
            title="Usuários Ativos"
            value={analyticsData?.activeUsers?.toLocaleString() || '0'}
            icon={Activity}
            trend={8.3}
            color="green"
          />
          <MetricCard
            title="Resíduos Processados"
            value={`${analyticsData?.wasteProcessed?.toLocaleString() || '0'} kg`}
            icon={Target}
            trend={15.7}
            color="purple"
          />
          <MetricCard
            title="CO₂ Economizado"
            value={`${analyticsData?.co2Saved?.toLocaleString() || '0'} kg`}
            icon={Globe}
            trend={22.1}
            color="emerald"
          />
        </div>

        {/* Métricas em Tempo Real */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
            <Activity className="w-5 h-5 mr-2 text-green-600" />
            Métricas em Tempo Real
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {analyticsData?.realTimeMetrics?.currentOnline || 0}
              </div>
              <div className="text-sm text-gray-600">Online Agora</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600 mb-1">
                {analyticsData?.realTimeMetrics?.scansLastHour || 0}
              </div>
              <div className="text-sm text-gray-600">Scans na Última Hora</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-1">
                {analyticsData?.realTimeMetrics?.tokensEarnedToday || 0}
              </div>
              <div className="text-sm text-gray-600">Tokens Hoje</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-1">
                {analyticsData?.realTimeMetrics?.wasteProcessedToday || 0} kg
              </div>
              <div className="text-sm text-gray-600">Resíduos Hoje</div>
            </div>
          </div>
        </div>

        {/* Gráficos */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Atividade por Hora */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-blue-600" />
              Atividade por Hora
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userActivity?.hourlyActivity || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="users" 
                  stroke="#3B82F6" 
                  fill="#3B82F6" 
                  fillOpacity={0.3}
                  name="Usuários"
                />
                <Area 
                  type="monotone" 
                  dataKey="scans" 
                  stroke="#10B981" 
                  fill="#10B981" 
                  fillOpacity={0.3}
                  name="Scans"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Distribuição de Dispositivos */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Smartphone className="w-5 h-5 mr-2 text-green-600" />
              Dispositivos
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={deviceData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {deviceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Países */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <Globe className="w-5 h-5 mr-2 text-purple-600" />
            Top Países por Usuários
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={countryData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="country" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="users" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Footer com informações da Edge */}
        <div className="mt-8 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-bold text-lg mb-2">Powered by Vercel Edge Functions</h4>
              <p className="text-green-100">
                Analytics processado na edge para máxima performance global
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">
                {analyticsData?.realTimeMetrics?.currentOnline || 0}
              </div>
              <div className="text-green-100 text-sm">
                Usuários Online
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdvancedAnalytics

