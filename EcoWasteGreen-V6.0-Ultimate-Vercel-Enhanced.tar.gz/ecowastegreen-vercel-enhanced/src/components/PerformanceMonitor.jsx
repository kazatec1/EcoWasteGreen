import React, { useState, useEffect } from 'react'
import { LineChart, Line, AreaChart, Area, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts'
import { Zap, Clock, Server, Wifi, AlertTriangle, CheckCircle, TrendingUp, Monitor } from 'lucide-react'

const PerformanceMonitor = () => {
  const [performanceData, setPerformanceData] = useState(null)
  const [realTimeMetrics, setRealTimeMetrics] = useState({
    responseTime: 0,
    throughput: 0,
    errorRate: 0,
    uptime: 99.9
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simular dados de performance em tempo real
    const generatePerformanceData = () => {
      const now = new Date()
      const data = []
      
      for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000)
        data.push({
          time: time.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          responseTime: Math.random() * 200 + 50,
          throughput: Math.random() * 1000 + 500,
          errorRate: Math.random() * 2,
          cpuUsage: Math.random() * 80 + 10,
          memoryUsage: Math.random() * 70 + 20,
          edgeHits: Math.random() * 100 + 50
        })
      }
      
      return data
    }

    const updateMetrics = () => {
      setRealTimeMetrics({
        responseTime: Math.random() * 100 + 50,
        throughput: Math.random() * 500 + 750,
        errorRate: Math.random() * 1,
        uptime: 99.9 + Math.random() * 0.1
      })
    }

    setPerformanceData(generatePerformanceData())
    setLoading(false)

    // Atualizar métricas a cada 5 segundos
    const interval = setInterval(() => {
      updateMetrics()
      setPerformanceData(generatePerformanceData())
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const getStatusColor = (value, thresholds) => {
    if (value <= thresholds.good) return 'text-green-600'
    if (value <= thresholds.warning) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getStatusIcon = (value, thresholds) => {
    if (value <= thresholds.good) return <CheckCircle className="w-5 h-5 text-green-600" />
    if (value <= thresholds.warning) return <AlertTriangle className="w-5 h-5 text-yellow-600" />
    return <AlertTriangle className="w-5 h-5 text-red-600" />
  }

  const MetricCard = ({ title, value, unit, icon: Icon, thresholds, trend }) => (
    <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <div className="p-3 rounded-lg bg-blue-100 mr-3">
            <Icon className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-gray-600 text-sm font-medium">{title}</h3>
            <div className="flex items-center">
              <span className={`text-2xl font-bold ${getStatusColor(value, thresholds)}`}>
                {typeof value === 'number' ? value.toFixed(1) : value}
              </span>
              <span className="text-gray-500 text-sm ml-1">{unit}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end">
          {getStatusIcon(value, thresholds)}
          {trend && (
            <div className={`flex items-center text-xs mt-1 ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="w-3 h-3 mr-1" />
              {trend > 0 ? '+' : ''}{trend.toFixed(1)}%
            </div>
          )}
        </div>
      </div>
    </div>
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="bg-white rounded-xl p-6 shadow-lg">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
            <Monitor className="w-8 h-8 mr-3 text-blue-600" />
            Performance Monitor
          </h1>
          <p className="text-gray-600">
            Monitoramento em tempo real da performance do EcoWaste Green
          </p>
        </div>

        {/* Métricas em Tempo Real */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Tempo de Resposta"
            value={realTimeMetrics.responseTime}
            unit="ms"
            icon={Clock}
            thresholds={{ good: 100, warning: 300 }}
            trend={-2.3}
          />
          <MetricCard
            title="Throughput"
            value={realTimeMetrics.throughput}
            unit="req/min"
            icon={Zap}
            thresholds={{ good: 1000, warning: 500 }}
            trend={5.7}
          />
          <MetricCard
            title="Taxa de Erro"
            value={realTimeMetrics.errorRate}
            unit="%"
            icon={AlertTriangle}
            thresholds={{ good: 1, warning: 3 }}
            trend={-0.5}
          />
          <MetricCard
            title="Uptime"
            value={realTimeMetrics.uptime}
            unit="%"
            icon={Server}
            thresholds={{ good: 99.9, warning: 99.5 }}
            trend={0.1}
          />
        </div>

        {/* Gráficos de Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Tempo de Resposta */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-blue-600" />
              Tempo de Resposta (24h)
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value.toFixed(1)}ms`, 'Tempo de Resposta']} />
                <Line 
                  type="monotone" 
                  dataKey="responseTime" 
                  stroke="#3B82F6" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Throughput */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Zap className="w-5 h-5 mr-2 text-green-600" />
              Throughput (24h)
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value.toFixed(0)} req/min`, 'Throughput']} />
                <Area 
                  type="monotone" 
                  dataKey="throughput" 
                  stroke="#10B981" 
                  fill="#10B981" 
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Métricas de Sistema */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* CPU e Memória */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Server className="w-5 h-5 mr-2 text-purple-600" />
              Uso de Recursos
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="cpuUsage" 
                  stroke="#8B5CF6" 
                  strokeWidth={2}
                  name="CPU (%)"
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="memoryUsage" 
                  stroke="#F59E0B" 
                  strokeWidth={2}
                  name="Memória (%)"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Edge Cache Hits */}
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
              <Wifi className="w-5 h-5 mr-2 text-orange-600" />
              Edge Cache Performance
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={performanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip formatter={(value) => [`${value.toFixed(0)}%`, 'Cache Hit Rate']} />
                <Area 
                  type="monotone" 
                  dataKey="edgeHits" 
                  stroke="#F59E0B" 
                  fill="#F59E0B" 
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status dos Serviços */}
        <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
            Status dos Serviços
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <div className="font-semibold text-gray-900">Edge Functions</div>
                  <div className="text-sm text-gray-600">Operacional</div>
                </div>
              </div>
              <div className="text-green-600 font-bold">99.9%</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <div className="font-semibold text-gray-900">API Serverless</div>
                  <div className="text-sm text-gray-600">Operacional</div>
                </div>
              </div>
              <div className="text-green-600 font-bold">99.8%</div>
            </div>

            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                <div>
                  <div className="font-semibold text-gray-900">CDN Global</div>
                  <div className="text-sm text-gray-600">Operacional</div>
                </div>
              </div>
              <div className="text-green-600 font-bold">100%</div>
            </div>
          </div>
        </div>

        {/* Core Web Vitals */}
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center">
            <TrendingUp className="w-5 h-5 mr-2 text-blue-600" />
            Core Web Vitals
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">1.2s</div>
              <div className="font-semibold text-gray-900">LCP</div>
              <div className="text-sm text-gray-600">Largest Contentful Paint</div>
              <div className="mt-2 text-xs text-green-600 font-medium">Bom</div>
            </div>

            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">0.08</div>
              <div className="font-semibold text-gray-900">FID</div>
              <div className="text-sm text-gray-600">First Input Delay</div>
              <div className="mt-2 text-xs text-green-600 font-medium">Bom</div>
            </div>

            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-3xl font-bold text-green-600 mb-2">0.05</div>
              <div className="font-semibold text-gray-900">CLS</div>
              <div className="text-sm text-gray-600">Cumulative Layout Shift</div>
              <div className="mt-2 text-xs text-green-600 font-medium">Bom</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-bold text-lg mb-2">Vercel Performance Monitoring</h4>
              <p className="text-blue-100">
                Monitoramento contínuo com alertas automáticos e otimização de performance
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">
                {realTimeMetrics.uptime.toFixed(1)}%
              </div>
              <div className="text-blue-100 text-sm">
                Uptime Global
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default PerformanceMonitor

