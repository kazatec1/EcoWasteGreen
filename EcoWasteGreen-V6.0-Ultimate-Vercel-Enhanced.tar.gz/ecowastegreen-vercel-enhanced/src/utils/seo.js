// Utilitários de SEO para EcoWaste Green V6.0 Ultimate
// Otimização para motores de busca e performance

export const seoConfig = {
  defaultTitle: 'EcoWaste Green V6.0 Ultimate - Reciclagem Inteligente com IA e Blockchain',
  titleTemplate: '%s | EcoWaste Green',
  defaultDescription: 'Revolucione sua reciclagem com IA, blockchain e gamificação. Scanner inteligente, ECO tokens, rede social ecológica e marketplace sustentável.',
  siteUrl: 'https://ecowastegreen.com',
  defaultImage: '/images/og-image.jpg',
  twitterHandle: '@ecowastegreen',
  language: 'pt-BR',
  locale: 'pt_BR',
  type: 'website',
}

export const generateMetaTags = ({
  title,
  description,
  image,
  url,
  type = 'website',
  article = null,
  noindex = false,
  canonical = null
}) => {
  const metaTitle = title ? `${title} | EcoWaste Green` : seoConfig.defaultTitle
  const metaDescription = description || seoConfig.defaultDescription
  const metaImage = image || seoConfig.defaultImage
  const metaUrl = url ? `${seoConfig.siteUrl}${url}` : seoConfig.siteUrl

  const tags = {
    // Básico
    title: metaTitle,
    description: metaDescription,
    
    // Viewport e responsividade
    viewport: 'width=device-width, initial-scale=1, maximum-scale=5',
    
    // Robots
    robots: noindex ? 'noindex, nofollow' : 'index, follow',
    
    // Canonical
    canonical: canonical || metaUrl,
    
    // Open Graph
    'og:title': metaTitle,
    'og:description': metaDescription,
    'og:image': metaImage,
    'og:url': metaUrl,
    'og:type': type,
    'og:site_name': 'EcoWaste Green',
    'og:locale': seoConfig.locale,
    
    // Twitter
    'twitter:card': 'summary_large_image',
    'twitter:site': seoConfig.twitterHandle,
    'twitter:creator': seoConfig.twitterHandle,
    'twitter:title': metaTitle,
    'twitter:description': metaDescription,
    'twitter:image': metaImage,
    
    // Idioma
    'language': seoConfig.language,
    'content-language': seoConfig.language,
    
    // Tema
    'theme-color': '#22c55e',
    'msapplication-TileColor': '#22c55e',
    
    // Apple
    'apple-mobile-web-app-capable': 'yes',
    'apple-mobile-web-app-status-bar-style': 'default',
    'apple-mobile-web-app-title': 'EcoWaste Green',
    
    // Manifest
    'manifest': '/manifest.json',
    
    // DNS Prefetch
    'dns-prefetch': '//fonts.googleapis.com',
    
    // Preconnect
    'preconnect': 'https://fonts.gstatic.com',
  }

  // Adicionar tags específicas para artigos
  if (type === 'article' && article) {
    tags['og:article:author'] = article.author || 'EcoWaste Green Team'
    tags['og:article:published_time'] = article.publishedTime
    tags['og:article:modified_time'] = article.modifiedTime
    tags['og:article:section'] = article.section || 'Sustentabilidade'
    tags['og:article:tag'] = article.tags?.join(', ') || 'reciclagem, sustentabilidade, meio ambiente'
  }

  return tags
}

export const generateStructuredData = (type, data) => {
  const baseData = {
    '@context': 'https://schema.org',
    '@type': type,
  }

  switch (type) {
    case 'WebSite':
      return {
        ...baseData,
        name: 'EcoWaste Green',
        url: seoConfig.siteUrl,
        description: seoConfig.defaultDescription,
        potentialAction: {
          '@type': 'SearchAction',
          target: `${seoConfig.siteUrl}/search?q={search_term_string}`,
          'query-input': 'required name=search_term_string'
        },
        sameAs: [
          'https://twitter.com/ecowastegreen',
          'https://facebook.com/ecowastegreen',
          'https://instagram.com/ecowastegreen',
          'https://linkedin.com/company/ecowastegreen'
        ]
      }

    case 'Organization':
      return {
        ...baseData,
        name: 'EcoWaste Green',
        url: seoConfig.siteUrl,
        logo: `${seoConfig.siteUrl}/images/logo.png`,
        description: seoConfig.defaultDescription,
        foundingDate: '2024',
        founders: [
          {
            '@type': 'Person',
            name: 'EcoWaste Green Team'
          }
        ],
        address: {
          '@type': 'PostalAddress',
          addressCountry: 'BR'
        },
        contactPoint: {
          '@type': 'ContactPoint',
          contactType: 'customer service',
          email: 'contato@ecowastegreen.com'
        }
      }

    case 'WebApplication':
      return {
        ...baseData,
        name: 'EcoWaste Green V6.0 Ultimate',
        url: seoConfig.siteUrl,
        description: seoConfig.defaultDescription,
        applicationCategory: 'EnvironmentalApplication',
        operatingSystem: 'Web, iOS, Android',
        offers: {
          '@type': 'Offer',
          price: '0',
          priceCurrency: 'BRL'
        },
        featureList: [
          'Scanner IA para identificação de resíduos',
          'Sistema de ECO Tokens blockchain',
          'Rede social ecológica',
          'Marketplace sustentável',
          'Gamificação e recompensas',
          'Analytics ambientais'
        ]
      }

    case 'Article':
      return {
        ...baseData,
        headline: data.title,
        description: data.description,
        image: data.image,
        author: {
          '@type': 'Person',
          name: data.author || 'EcoWaste Green Team'
        },
        publisher: {
          '@type': 'Organization',
          name: 'EcoWaste Green',
          logo: {
            '@type': 'ImageObject',
            url: `${seoConfig.siteUrl}/images/logo.png`
          }
        },
        datePublished: data.publishedTime,
        dateModified: data.modifiedTime || data.publishedTime,
        mainEntityOfPage: {
          '@type': 'WebPage',
          '@id': data.url
        }
      }

    case 'Product':
      return {
        ...baseData,
        name: data.name,
        description: data.description,
        image: data.image,
        brand: {
          '@type': 'Brand',
          name: 'EcoWaste Green'
        },
        category: data.category || 'Produto Sustentável',
        offers: {
          '@type': 'Offer',
          price: data.price || '0',
          priceCurrency: data.currency || 'ECO',
          availability: 'https://schema.org/InStock',
          seller: {
            '@type': 'Organization',
            name: 'EcoWaste Green Marketplace'
          }
        },
        aggregateRating: data.rating ? {
          '@type': 'AggregateRating',
          ratingValue: data.rating.value,
          reviewCount: data.rating.count
        } : undefined
      }

    default:
      return baseData
  }
}

export const generateBreadcrumbs = (items) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: `${seoConfig.siteUrl}${item.url}`
    }))
  }
}

export const generateFAQStructuredData = (faqs) => {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer
      }
    }))
  }
}

// Utilitários para otimização de performance
export const preloadCriticalResources = () => {
  return [
    // Preload de fontes críticas
    {
      rel: 'preload',
      href: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
      as: 'style'
    },
    // Preload de imagens críticas
    {
      rel: 'preload',
      href: '/images/hero-bg.webp',
      as: 'image',
      type: 'image/webp'
    },
    // Preload de scripts críticos
    {
      rel: 'preload',
      href: '/js/critical.js',
      as: 'script'
    }
  ]
}

export const generateSitemap = (pages) => {
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map(page => `
  <url>
    <loc>${seoConfig.siteUrl}${page.url}</loc>
    <lastmod>${page.lastmod || new Date().toISOString()}</lastmod>
    <changefreq>${page.changefreq || 'weekly'}</changefreq>
    <priority>${page.priority || '0.8'}</priority>
  </url>
`).join('')}
</urlset>`

  return sitemap
}

export const generateRobotsTxt = () => {
  return `User-agent: *
Allow: /

User-agent: Googlebot
Allow: /

User-agent: Bingbot
Allow: /

Disallow: /api/
Disallow: /admin/
Disallow: /_next/
Disallow: /private/

Sitemap: ${seoConfig.siteUrl}/sitemap.xml
Sitemap: ${seoConfig.siteUrl}/sitemap-images.xml

# Crawl-delay for respectful crawling
Crawl-delay: 1`
}

// Utilitários para Core Web Vitals
export const optimizeImages = {
  // Configurações para diferentes tipos de imagem
  hero: {
    sizes: '100vw',
    priority: true,
    quality: 85,
    format: ['webp', 'avif']
  },
  thumbnail: {
    sizes: '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw',
    quality: 75,
    format: ['webp']
  },
  icon: {
    sizes: '48px',
    quality: 90,
    format: ['webp', 'png']
  }
}

export const criticalCSS = `
/* Critical CSS para Above-the-fold */
body {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  margin: 0;
  padding: 0;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
}

.hero-section {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #22c55e, #3b82f6);
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid #f3f3f3;
  border-top: 4px solid #22c55e;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
`

