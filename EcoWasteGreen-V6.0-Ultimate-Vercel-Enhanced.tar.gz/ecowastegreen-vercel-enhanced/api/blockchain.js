// Serverless Function para Blockchain - EcoWaste Green V6.0 Ultimate
// Gerenciamento de ECO Tokens e transações

export default async function handler(req, res) {
  // Headers CORS
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization')

  if (req.method === 'OPTIONS') {
    return res.status(200).end()
  }

  try {
    const { method, query, body } = req
    const { action, userId, address } = method === 'GET' ? query : body

    // Simulação de dados blockchain
    const blockchainData = {
      network: 'EcoChain',
      chainId: 'eco-mainnet-1',
      blockHeight: 2847592,
      gasPrice: '0.001 ECO',
      totalSupply: '1000000000 ECO',
      circulatingSupply: '450000000 ECO'
    }

    if (method === 'GET') {
      switch (action) {
        case 'wallet':
          if (!userId) {
            return res.status(400).json({
              success: false,
              error: 'userId is required'
            })
          }

          // Simular dados da carteira
          const walletData = {
            success: true,
            wallet: {
              address: `eco1${Math.random().toString(36).substr(2, 38)}`,
              balance: {
                eco: (Math.random() * 1000).toFixed(2),
                usd: (Math.random() * 500).toFixed(2)
              },
              transactions: [
                {
                  id: 'tx_001',
                  type: 'earn',
                  amount: '10.5',
                  description: 'Plastic bottle recycling',
                  timestamp: new Date(Date.now() - 3600000).toISOString(),
                  status: 'confirmed'
                },
                {
                  id: 'tx_002',
                  type: 'earn',
                  amount: '8.0',
                  description: 'Paper recycling',
                  timestamp: new Date(Date.now() - 7200000).toISOString(),
                  status: 'confirmed'
                },
                {
                  id: 'tx_003',
                  type: 'spend',
                  amount: '-15.0',
                  description: 'Eco product purchase',
                  timestamp: new Date(Date.now() - 86400000).toISOString(),
                  status: 'confirmed'
                }
              ],
              stats: {
                totalEarned: (Math.random() * 5000).toFixed(2),
                totalSpent: (Math.random() * 2000).toFixed(2),
                recyclingStreak: Math.floor(Math.random() * 30) + 1,
                rank: Math.floor(Math.random() * 1000) + 1
              }
            },
            blockchain: blockchainData,
            timestamp: new Date().toISOString()
          }

          return res.status(200).json(walletData)

        case 'transactions':
          const page = parseInt(query.page) || 1
          const limit = parseInt(query.limit) || 10
          
          // Simular histórico de transações
          const transactions = Array.from({ length: limit }, (_, i) => ({
            id: `tx_${Date.now()}_${i}`,
            type: Math.random() > 0.7 ? 'spend' : 'earn',
            amount: (Math.random() * 50).toFixed(2),
            description: [
              'Plastic bottle recycling',
              'Paper recycling',
              'Glass jar recycling',
              'Aluminum can recycling',
              'Eco product purchase',
              'Carbon offset purchase',
              'Tree planting donation'
            ][Math.floor(Math.random() * 7)],
            timestamp: new Date(Date.now() - Math.random() * 2592000000).toISOString(),
            status: 'confirmed',
            hash: `0x${Math.random().toString(16).substr(2, 64)}`
          }))

          return res.status(200).json({
            success: true,
            transactions,
            pagination: {
              page,
              limit,
              total: 1247,
              pages: Math.ceil(1247 / limit)
            },
            blockchain: blockchainData
          })

        case 'leaderboard':
          const leaderboard = Array.from({ length: 10 }, (_, i) => ({
            rank: i + 1,
            userId: `user_${Math.random().toString(36).substr(2, 8)}`,
            username: `EcoWarrior${i + 1}`,
            balance: (Math.random() * 10000).toFixed(2),
            recyclingCount: Math.floor(Math.random() * 500) + 100,
            co2Saved: (Math.random() * 1000).toFixed(2),
            country: ['Brazil', 'USA', 'Germany', 'Japan', 'France'][Math.floor(Math.random() * 5)]
          }))

          return res.status(200).json({
            success: true,
            leaderboard,
            userRank: Math.floor(Math.random() * 1000) + 1,
            totalUsers: 15420,
            blockchain: blockchainData
          })

        case 'stats':
          return res.status(200).json({
            success: true,
            stats: {
              totalTokensEarned: '45672891.50',
              totalTransactions: 2847592,
              activeWallets: 15420,
              averageEarningsPerUser: '2963.45',
              topEarningCategory: 'Plastic Recycling',
              networkHealth: 99.8,
              carbonOffsetFunded: '125847.2 tons',
              treesPlanted: 45672
            },
            blockchain: blockchainData,
            timestamp: new Date().toISOString()
          })

        default:
          return res.status(400).json({
            success: false,
            error: 'Invalid action'
          })
      }
    }

    if (method === 'POST') {
      switch (action) {
        case 'transfer':
          const { toAddress, amount, memo } = body

          if (!userId || !toAddress || !amount) {
            return res.status(400).json({
              success: false,
              error: 'Missing required fields'
            })
          }

          // Simular transferência
          const transferResult = {
            success: true,
            transaction: {
              id: `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              from: `eco1${Math.random().toString(36).substr(2, 38)}`,
              to: toAddress,
              amount,
              memo: memo || '',
              fee: '0.001',
              status: 'pending',
              hash: `0x${Math.random().toString(16).substr(2, 64)}`,
              timestamp: new Date().toISOString(),
              estimatedConfirmation: '2-3 minutes'
            },
            blockchain: blockchainData
          }

          return res.status(200).json(transferResult)

        case 'earn':
          const { recyclingType, quantity, location } = body

          if (!userId || !recyclingType || !quantity) {
            return res.status(400).json({
              success: false,
              error: 'Missing required fields'
            })
          }

          // Calcular tokens baseado no tipo de reciclagem
          const rates = {
            plastic: 10,
            paper: 8,
            glass: 15,
            metal: 20,
            organic: 5
          }

          const baseAmount = rates[recyclingType] || 5
          const earnedAmount = (baseAmount * quantity).toFixed(2)
          const co2Saved = (earnedAmount * 0.1).toFixed(2)

          const earnResult = {
            success: true,
            transaction: {
              id: `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              type: 'earn',
              amount: earnedAmount,
              recyclingType,
              quantity,
              location: location || 'Unknown',
              co2Saved,
              status: 'confirmed',
              timestamp: new Date().toISOString()
            },
            newBalance: (Math.random() * 1000 + parseFloat(earnedAmount)).toFixed(2),
            achievements: Math.random() > 0.8 ? [
              {
                id: 'eco_warrior',
                name: 'Eco Warrior',
                description: 'Recycled 100 items this month!',
                reward: '50 ECO'
              }
            ] : [],
            blockchain: blockchainData
          }

          return res.status(200).json(earnResult)

        default:
          return res.status(400).json({
            success: false,
            error: 'Invalid action'
          })
      }
    }

    return res.status(405).json({
      success: false,
      error: 'Method not allowed'
    })

  } catch (error) {
    console.error('Blockchain API Error:', error)
    
    return res.status(500).json({
      success: false,
      error: 'Internal server error',
      timestamp: new Date().toISOString()
    })
  }
}

