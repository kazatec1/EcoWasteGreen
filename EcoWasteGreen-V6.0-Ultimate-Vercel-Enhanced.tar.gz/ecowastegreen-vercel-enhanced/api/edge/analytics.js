// Edge Function para Analytics em Tempo Real - EcoWaste Green V6.0 Ultimate
// Executa na edge para máxima performance

export const config = {
  runtime: 'edge',
  regions: ['iad1', 'sfo1', 'fra1', 'hnd1', 'syd1']
}

export default async function handler(request) {
  const { method, url, headers } = request
  const { searchParams } = new URL(url)
  
  // Headers de segurança
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store, must-revalidate'
  }

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders })
  }

  try {
    // Coletar dados de analytics
    const userAgent = headers.get('user-agent') || ''
    const referer = headers.get('referer') || ''
    const country = headers.get('cf-ipcountry') || 'Unknown'
    const timestamp = new Date().toISOString()
    
    // Detectar dispositivo
    const isMobile = /Mobile|Android|iPhone|iPad/.test(userAgent)
    const isBot = /bot|crawler|spider/i.test(userAgent)
    
    if (method === 'GET') {
      // Endpoint para obter estatísticas
      const action = searchParams.get('action')
      
      switch (action) {
        case 'stats':
          return new Response(JSON.stringify({
            success: true,
            data: {
              totalUsers: 15420,
              activeUsers: 1250,
              wasteProcessed: 45672.5,
              co2Saved: 22836.25,
              ecoTokensEarned: 892450,
              topCountries: [
                { country: 'Brazil', users: 4521, percentage: 29.3 },
                { country: 'United States', users: 3102, percentage: 20.1 },
                { country: 'Germany', users: 2456, percentage: 15.9 },
                { country: 'Japan', users: 1890, percentage: 12.3 },
                { country: 'France', users: 1234, percentage: 8.0 }
              ],
              deviceBreakdown: {
                mobile: 68.5,
                desktop: 28.2,
                tablet: 3.3
              },
              realTimeMetrics: {
                currentOnline: 342,
                scansLastHour: 156,
                tokensEarnedToday: 2450,
                wasteProcessedToday: 125.8
              }
            },
            timestamp,
            edge: {
              region: headers.get('cf-ray')?.split('-')[1] || 'unknown',
              country,
              responseTime: Date.now()
            }
          }), {
            status: 200,
            headers: corsHeaders
          })

        case 'user-activity':
          return new Response(JSON.stringify({
            success: true,
            data: {
              hourlyActivity: [
                { hour: '00:00', users: 45, scans: 12 },
                { hour: '01:00', users: 32, scans: 8 },
                { hour: '02:00', users: 28, scans: 5 },
                { hour: '03:00', users: 25, scans: 4 },
                { hour: '04:00', users: 30, scans: 7 },
                { hour: '05:00', users: 42, scans: 15 },
                { hour: '06:00', users: 78, scans: 28 },
                { hour: '07:00', users: 125, scans: 45 },
                { hour: '08:00', users: 189, scans: 67 },
                { hour: '09:00', users: 234, scans: 89 },
                { hour: '10:00', users: 267, scans: 102 },
                { hour: '11:00', users: 298, scans: 115 },
                { hour: '12:00', users: 342, scans: 134 },
                { hour: '13:00', users: 356, scans: 142 },
                { hour: '14:00', users: 334, scans: 128 },
                { hour: '15:00', users: 312, scans: 118 },
                { hour: '16:00', users: 289, scans: 105 },
                { hour: '17:00', users: 267, scans: 98 },
                { hour: '18:00', users: 245, scans: 87 },
                { hour: '19:00', users: 198, scans: 72 },
                { hour: '20:00', users: 156, scans: 58 },
                { hour: '21:00', users: 123, scans: 42 },
                { hour: '22:00', users: 89, scans: 28 },
                { hour: '23:00', users: 67, scans: 18 }
              ],
              peakHour: '13:00',
              averageSessionTime: '8m 34s',
              bounceRate: 23.5
            },
            timestamp,
            edge: { country, isMobile }
          }), {
            status: 200,
            headers: corsHeaders
          })

        default:
          return new Response(JSON.stringify({
            success: false,
            error: 'Invalid action parameter'
          }), {
            status: 400,
            headers: corsHeaders
          })
      }
    }

    if (method === 'POST') {
      // Endpoint para registrar eventos
      const body = await request.json()
      const { event, userId, data } = body

      // Simular processamento de evento
      const eventData = {
        eventId: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        event,
        userId,
        data,
        metadata: {
          timestamp,
          country,
          isMobile,
          isBot,
          userAgent: userAgent.substring(0, 100),
          referer
        }
      }

      // Em produção, aqui salvaria no banco de dados ou analytics service
      console.log('Event tracked:', eventData)

      return new Response(JSON.stringify({
        success: true,
        eventId: eventData.eventId,
        message: 'Event tracked successfully',
        timestamp
      }), {
        status: 200,
        headers: corsHeaders
      })
    }

    return new Response(JSON.stringify({
      success: false,
      error: 'Method not allowed'
    }), {
      status: 405,
      headers: corsHeaders
    })

  } catch (error) {
    console.error('Analytics Edge Function Error:', error)
    
    return new Response(JSON.stringify({
      success: false,
      error: 'Internal server error',
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: corsHeaders
    })
  }
}

